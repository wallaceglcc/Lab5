﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using CustomerMaintenance;

namespace ProductDBTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetProduct()
        {
            Product p1 = ProductDB.GetProduct("2JST");
            Assert.IsTrue(p1.ProductCode == "2JST");
            Assert.IsTrue(p1.Description == "Murach's JavaScript (2nd Edition)");
            Assert.IsTrue(p1.UnitPrice == 54.50m);
            Assert.IsTrue(p1.OnHandQuantity == 6937);
        }

        [TestMethod]
        public void TestUpdateProduct()
        {
            Product p2 = new Product("2QRY", "b", 1m, 2);
            Product p3 = new Product("2QRY", "d", 3m, 4);
            ProductDB.UpdateProduct(p2, p3);
            p2 = ProductDB.GetProduct("2QRY");
            Assert.IsTrue(p2.ProductCode == "2QRY", p2.ProductCode);
            Assert.IsTrue(p2.Description == "d", p2.Description);
            Assert.IsTrue(p2.UnitPrice == 3m, p2.UnitPrice.ToString());
            Assert.IsTrue(p2.OnHandQuantity == 4, p2.OnHandQuantity.ToString());
            p2 = new Product("2QRY", "b", 1m, 2);
            ProductDB.UpdateProduct(p3, p2);
            p3 = ProductDB.GetProduct("2QRY");
            Assert.IsTrue(p2.ProductCode == "2QRY", p2.ProductCode);
            Assert.IsTrue(p2.Description == "b", p2.Description);
            Assert.IsTrue(p2.UnitPrice == 1m, p2.UnitPrice.ToString());
            Assert.IsTrue(p2.OnHandQuantity == 2, p2.OnHandQuantity.ToString());
        }

        [TestMethod]
        public void TestAddDeleteProduct()
        {
            Assert.IsNull(ProductDB.GetProduct("TEST"));
            Product p4 = new Product("TEST", "a", 1m, 2);
            ProductDB.AddProduct(p4);
            p4 = ProductDB.GetProduct("TEST");
            Assert.IsTrue(p4.ProductCode == "TEST" && p4.Description == "a" && p4.UnitPrice == 1m && p4.OnHandQuantity == 2, "Match Failed");
            Assert.IsTrue(ProductDB.DeleteProduct(p4), "Delete Failed");
            Assert.IsNull(ProductDB.GetProduct("TEST"));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CustomerMaintenance
{
    public class CustomerDB
    {
        static public Customer GetCustomer(int cid)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string selectString 
                = "SELECT CustomerID, Name, Address, City, State, ZipCode " 
                + "FROM Customers " 
                + "WHERE CustomerID = @CustomerID";
            SqlCommand selectCommand = new SqlCommand(selectString, connection);
            selectCommand.Parameters.AddWithValue("@CustomerID", cid);
            try
            {
                connection.Open();
                SqlDataReader custReader = selectCommand.ExecuteReader(CommandBehavior.SingleRow);
                if(custReader.Read())
                {
                    Customer customer = new Customer();
                    customer.CustomerID = (int)custReader["CustomerID"];
                    customer.Address = custReader["Address"].ToString();
                    customer.Name = custReader["Name"].ToString();
                    customer.State = custReader["State"].ToString();
                    customer.City = custReader["City"].ToString();
                    customer.ZipCode = custReader["ZipCode"].ToString();
                    return customer;
                }
                else
                {
                    return null;
                }
            }
            catch(SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        static public bool UpdateCustomer(Customer c1, Customer c2)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string updateString
                = "UPDATE Customers SET "
                + "Name = @NewName, "
                + "Address = @NewAddress, "
                + "City = @NewCity, "
                + "State = @NewState, "
                + "ZipCode = @NewZipCode "
                + "WHERE CustomerID = @OldCustomerID "
                + "AND Name = @OldName "
                + "AND Address = @OldAddress "
                + "AND City = @OldCity "
                + "AND State = @OldState "
                + "AND ZipCode = @OldZipCode ";
            SqlCommand updateCommand = new SqlCommand(updateString, connection);
            updateCommand.Parameters.AddWithValue("@NewName", c2.Name);
            updateCommand.Parameters.AddWithValue("@NewAddress", c2.Address);
            updateCommand.Parameters.AddWithValue("@NewCity", c2.City);
            updateCommand.Parameters.AddWithValue("@NewState", c2.State);
            updateCommand.Parameters.AddWithValue("@NewZipCode", c2.ZipCode);
            updateCommand.Parameters.AddWithValue("@OldAddress", c1.Address);
            updateCommand.Parameters.AddWithValue("@OldCity", c1.City);
            updateCommand.Parameters.AddWithValue("@OldState", c1.State);
            updateCommand.Parameters.AddWithValue("@OldZipCode", c1.ZipCode);
            updateCommand.Parameters.AddWithValue("@OldName", c1.Name);
            updateCommand.Parameters.AddWithValue("@OldCustomerID", c1.CustomerID);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if(count > 0) { return true; }
                else { return false; }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        public static int AddCustomer(Customer c1)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string insertString
                = "INSERT INTO Customers (Name, Address, City, State, ZipCode) VALUES (@Name, @Address, @City, @State, @ZipCode)";
            SqlCommand insertCommand = new SqlCommand(insertString, connection);
            insertCommand.Parameters.AddWithValue("@Name", c1.Name);
            insertCommand.Parameters.AddWithValue("@Address", c1.Address);
            insertCommand.Parameters.AddWithValue("@City", c1.City);
            insertCommand.Parameters.AddWithValue("@State", c1.State);
            insertCommand.Parameters.AddWithValue("@ZipCode", c1.ZipCode);
            insertCommand.Parameters.AddWithValue("@OldName", c1.Name);
            try
            {
                connection.Open();
                insertCommand.ExecuteNonQuery();
                string selectString = "SELECT IDENT_CURRENT('Customers') FROM Customers";
                SqlCommand selectCommand = new SqlCommand(selectString, connection);
                int customerID = Convert.ToInt32(selectCommand.ExecuteScalar());
                return customerID;
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool DeleteCustomer(Customer c1)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string deleteString
                = "DELETE FROM Customers "
                + "WHERE CustomerID = @CustomerID "
                + "AND Name = @Name "
                + "AND Address = @Address "
                + "AND City = @City "
                + "AND State = @State "
                + "AND ZipCode = @ZipCode ";
            SqlCommand updateCommand = new SqlCommand(deleteString, connection);
            updateCommand.Parameters.AddWithValue("@Address", c1.Address);
            updateCommand.Parameters.AddWithValue("@City", c1.City);
            updateCommand.Parameters.AddWithValue("@State", c1.State);
            updateCommand.Parameters.AddWithValue("@ZipCode", c1.ZipCode);
            updateCommand.Parameters.AddWithValue("@Name", c1.Name);
            updateCommand.Parameters.AddWithValue("@CustomerID", c1.CustomerID);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0) { return true; }
                else { return false; }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

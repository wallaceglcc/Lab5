﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CustomerMaintenance
{
    class StateDB
    {
        public static List<State> GetStates()
        {
            List<State> states = new List<State>();
            SqlConnection connect = MMABooksDB.GetConnection();
            string selectString
                    = "SELECT StateCode, StateName "
                    + "FROM States "
                    + "GROUP BY StateCode, StateName";
            SqlCommand selectCommand = new SqlCommand(selectString, connect);
            try
            {
                connect.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                while(reader.Read())
                {
                    State s = new State();
                    s.StateCode = reader["StateCode"].ToString();
                    s.StateName = reader["StateName"].ToString();
                    //State s = new State(reader["StateCode"].ToString(), reader["StateName"].ToString());
                    states.Add(s);
                }
                reader.Close();
            }
            catch(SqlException e)
            {
                throw e;
            }
            finally
            {
                connect.Close();
            }
            return states;
        }
    }
}

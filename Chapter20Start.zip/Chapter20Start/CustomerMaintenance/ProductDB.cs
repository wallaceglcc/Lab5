﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CustomerMaintenance
{
    public class ProductDB
    {
        /// <summary>
        /// Product reader. Modiefied version of Customer reader.
        /// </summary>
        /// <param name="pc"></param>
        /// <returns>Product read</returns>
        static public Product GetProduct(string pc)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string selectString
                = "SELECT ProductCode, Description, UnitPrice, OnHandQuantity "
                + "FROM Products "
                + "WHERE ProductCode = @ProductCode";
            SqlCommand selectCommand = new SqlCommand(selectString, connection);
            selectCommand.Parameters.AddWithValue("@ProductCode", pc);
            try
            {
                connection.Open();
                SqlDataReader productReader = selectCommand.ExecuteReader(CommandBehavior.SingleRow);
                if (productReader.Read())
                {
                    Product product = new Product();
                    product.ProductCode = productReader["ProductCode"].ToString().Trim();
                    product.Description = productReader["Description"].ToString().Trim();
                    product.UnitPrice = (decimal)productReader["UnitPrice"];
                    product.OnHandQuantity = (int)productReader["OnHandQuantity"];
                    return product;
                }
                else
                {
                    return null;
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Product updater. Edited version of customer updater.
        /// </summary>
        /// <param name="c1"></param>
        /// <param name="c2"></param>
        /// <returns>Whether the product was updated</returns>
        static public bool UpdateProduct(Product c1, Product c2)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string updateString
                = "UPDATE Products SET "
                + "Description = @NewDescription, "
                + "UnitPrice = @NewUnitPrice, "
                + "OnHandQuantity = @NewOnHandQuantity "
                + "WHERE ProductCode = @OldProductCode "
                + "AND Description = @OldDescription "
                + "AND UnitPrice = @OldUnitPrice "
                + "AND OnHandQuantity = @OldOnHandQuantity ";
            SqlCommand updateCommand = new SqlCommand(updateString, connection);
            updateCommand.Parameters.AddWithValue("@NewDescription", c2.Description);
            updateCommand.Parameters.AddWithValue("@NewUnitPrice", c2.UnitPrice);
            updateCommand.Parameters.AddWithValue("@NewOnHandQuantity", c2.OnHandQuantity);
            updateCommand.Parameters.AddWithValue("@OldProductCode", c1.ProductCode);
            updateCommand.Parameters.AddWithValue("@OldDescription", c1.Description);
            updateCommand.Parameters.AddWithValue("@OldUnitPrice", c1.UnitPrice);
            updateCommand.Parameters.AddWithValue("@OldOnHandQuantity", c1.OnHandQuantity);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0) { return true; }
                else { return false; }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Product creator. Edited version of customer creator.
        /// </summary>
        /// <param name="c1"></param>
        /// <returns>Returns true if successful</returns>
        public static bool AddProduct(Product c1)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string insertString
                = "INSERT INTO Products (ProductCode, Description, UnitPrice, OnHandQuantity) VALUES (@ProductCode, @Description, @UnitPrice, @OnHandQuantity)";
            SqlCommand insertCommand = new SqlCommand(insertString, connection);
            insertCommand.Parameters.AddWithValue("@ProductCode", c1.ProductCode);
            insertCommand.Parameters.AddWithValue("@Description", c1.Description);
            insertCommand.Parameters.AddWithValue("@UnitPrice", c1.UnitPrice);
            insertCommand.Parameters.AddWithValue("@OnHandQuantity", c1.OnHandQuantity);
            try
            {
                connection.Open();
                insertCommand.ExecuteNonQuery();
                return true;
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Product deleter. Modified version of Customer deleter
        /// </summary>
        /// <param name="c1"></param>
        /// <returns>Whether deleting was successful</returns>
        public static bool DeleteProduct(Product c1)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string deleteString
                = "DELETE FROM Products "
                + "WHERE ProductCode = @ProductCode "
                + "AND Description = @Description "
                + "AND UnitPrice = @UnitPrice "
                + "AND OnHandQuantity = @OnHandQuantity ";
            SqlCommand updateCommand = new SqlCommand(deleteString, connection);
            updateCommand.Parameters.AddWithValue("@ProductCode", c1.ProductCode);
            updateCommand.Parameters.AddWithValue("@Description", c1.Description);
            updateCommand.Parameters.AddWithValue("@UnitPrice", c1.UnitPrice);
            updateCommand.Parameters.AddWithValue("@OnHandQuantity", c1.OnHandQuantity);
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0) { return true; }
                else { return false; }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

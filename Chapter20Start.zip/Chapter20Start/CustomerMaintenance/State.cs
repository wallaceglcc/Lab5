﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMaintenance
{
    public class State
    {
        public State() { }

        public State(string sc, string sn)
        {
            StateCode = sc;
            StateName = sn;
        }

        public string StateCode { get; set; }

        public string StateName { get; set; }
    }
}
